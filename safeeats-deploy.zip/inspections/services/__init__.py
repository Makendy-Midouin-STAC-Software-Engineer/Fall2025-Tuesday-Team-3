"""Service package for inspections app."""
