"""Test suite for inspections app."""

